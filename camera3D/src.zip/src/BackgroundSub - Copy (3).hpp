/*#include "opencv2/video/tracking.hpp"
#include "opencv2/imgproc/imgproc.hpp"
#include "opencv2/highgui/highgui.hpp"
#include "opencv2/video/background_segm.hpp"
#include "opencv2/features2d/features2d.hpp"
#include <stdio.h>*/
//using namespace cv;

// use this one for better implementation/demonstartion:
// http://docs.opencv.org/master/d1/dc5/tutorial_background_subtraction.html#gsc.tab=0 

// ref by http://docs.opencv.org/2.4/doc/tutorials/imgproc/shapedescriptors/bounding_rects_circles/bounding_rects_circles.html 
// http://docs.opencv.org/3.1.0/dd/d49/tutorial_py_contour_features.html#gsc.tab=0

#include "opencv2/opencv.hpp"
using namespace cv;


// the function draws all the squares in the image
static void drawShapesContours(Mat& image, const vector<vector<Point> >& ShapesContours)
{
	for (size_t i = 0; i < ShapesContours.size(); i++)
	{
		const Point* p	= &ShapesContours[i][0];
		int n			= (int)ShapesContours[i].size();
		polylines(image, &p, &n, 1, true, Scalar(0, 255, 0), 3, LINE_AA);
	}

	imshow("Capture ", image);
}

int show_forgnd_and_bgnd()
{
    VideoCapture cap;
	String vidName = ""; 
	//String vidName = "pool.avi";
	String StatusText = "NAN";


	if (vidName =="")
		//TODO: need to define resulution
		cap.open(0); // Bu �ekliyle uygun olan Web kameras�n� a�ar ve g�r�nt�y� ordan al�r bu ast�r� a�arsan�z alttaki sat�r� kapat�n
	else
		cap.open(vidName);
	cvWaitKey(100); // initial delay for init
    
    if( !cap.isOpened() )
    {
        puts("***Could not initialize capturing...***\n");
        return 0;
    }

    namedWindow( "Capture "		, CV_WINDOW_AUTOSIZE);
    namedWindow( "Foreground "	, CV_WINDOW_AUTOSIZE );
    Mat frame,foreground,image;
	//utils
	vector<vector<Point> > contours;
	vector<vector<Point> > shapes_contours;
	int size;
	Rect rect;
	///Seq* contours_arr = 0;

	cv::Ptr<BackgroundSubtractorMOG2> mog = createBackgroundSubtractorMOG2(3/*0*/, 16.0, false);

    int fps=cap.get(CV_CAP_PROP_FPS);
	int loopWait = 0;

    if(fps<=0)
        loopWait=33;
    else
        loopWait=1000/fps; // 1000/30=33; 1000/15=67

    for(;;)
    {
		shapes_contours.clear();

        cap>>frame;   // Bir frame al�yoruz
        if( frame.empty() )
                break;

        image=frame.clone();

		// TODO: resize image if not set in init. or use different resulutions for capture and for analysis.
		//	// to gray, 
		//gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
		//	gray = cv2.GaussianBlur(gray, (21, 21), 0)

        // Arka plan ��karma k�sm�
		mog->apply(frame,foreground); //foreground = frame;//  ~absdiff()  //using c:\OpenCV\sources\modules\video\src\bgfg_gaussmix2.cpp
        // Ufak tefek temizlik


        threshold	(foreground,	foreground,	/*1*/28,	255,THRESH_BINARY);
        medianBlur	(foreground,	foreground,	9);
        erode		(foreground,	foreground,	Mat());
        dilate		(foreground,	foreground,	Mat());

		// draw cursers on screen
		// draw distance of target from screenn center
		// set text strings and text layer to display		

		/// my addition

		// find contours and store them all as a list
		//findContours(gray, contours, RETR_LIST, CHAIN_APPROX_SIMPLE);
		findContours(foreground.clone(), contours,RETR_EXTERNAL, CHAIN_APPROX_SIMPLE);// See squares.c in the OpenCV sample directory.
		/*# 
			# compute the bounding box for the contour, draw it on the frame,
			# and update the text
			(x, y, w, h) = cv2.boundingRect(c)
			cv2.rectangle(frame, (x, y), (x + w, y + h), (0, 255, 0), 2)
			text = "Occupied"*/
		vector<Point> approx;
		//////////////////////////

		/// Approximate contours to polygons + get bounding rects and circles
		vector<vector<Point> > contours_poly(contours.size());
		vector<Rect> boundRect(contours.size());
		vector<Point2f>center(contours.size());
		vector<float>radius(contours.size());

		//for (int i = 0; i < contours.size(); i++)
		//{
		//	approxPolyDP(Mat(contours[i]), contours_poly[i], 3, true);
		//	boundRect[i] = boundingRect(Mat(contours_poly[i]));
		//	minEnclosingCircle((Mat)contours_poly[i], center[i], radius[i]);
		//}


		///// Draw polygonal contour + bonding rects + circles
		//Mat drawing = image; // Mat::zeros(foreground.size(), CV_8UC3);
		//for (int i = 0; i< contours.size(); i++)
		//{

		//	RNG rng(12345);
		//	Scalar color = Scalar(rng.uniform(0, 255), rng.uniform(0, 255), rng.uniform(0, 255));
		//	drawContours(drawing, contours_poly, i, color, 1, 8, vector<Vec4i>(), 0, Point());
		//	rectangle(drawing, boundRect[i].tl(), boundRect[i].br(), color, 2, 8, 0);
		//	circle(drawing, center[i], (int)radius[i], color, 2, 8, 0);
		//}


		//////////////////////////
//			 test each contour
		for (size_t i = 0; i < contours.size(); i++)
		{
			// approximate contour with accuracy proportional to the contour perimeter
		    approxPolyDP(Mat(contours[i]), approx, arcLength(Mat(contours[i]), true)*0.02, true);	
			//	 boundingRect(Mat(contours_poly[i]));
			boundRect[i] = boundingRect(approx);
			//drawing rectangle
			rectangle(image,
			/*	Point(rect.x, rect.y),
				Point(rect.x + rect.width, rect.y + rect.height),*/
				boundRect[i].tl(), boundRect[i].br(),
				Scalar(0, 0, 255, 0),
				2, 8, 0);
			// contours should have relatively large area (to filter out noisy contours)
			// and be convex.
			// Note: absolute value of an area is used because
			// area may be positive or negative - in accordance with the
			// contour orientation

			////size = fabs(contourArea(Mat(approx)));
			//if (size > 1000 && size < 151000 && isContourConvex(Mat(approx)))
				//shapes_contours.push_back(approx);
			size = fabs(contourArea(Mat(contours[i])));
			//if (size > 100 && size < 151000 && isContourConvex(Mat(contours[i])))
				shapes_contours.push_back(contours[i]);
		}
        imshow( "Capture "	,image );
		//drawShapesContours(image, shapes_contours);
		/*imshow("Capture 2", drawing);*/

			///////

        // Ekranda g�sterme k�sm�
        // image.copyTo(foreground,foreground); // birde b�yle deneyin bakal�m ne olacak
        imshow("Foreground ",foreground);

        char c = (char)waitKey(loopWait);
        if( c == 27 )   // ESC tu�una bas�lana kadar �al��
            break;

    }


}
