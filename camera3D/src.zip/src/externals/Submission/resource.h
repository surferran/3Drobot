//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by UsingOpenCV.rc
//
#define IDC_MYICON                      2
#define IDD_USINGOPENCV_DIALOG          102
#define IDS_APP_TITLE                   103
#define IDD_ABOUTBOX                    103
#define IDM_ABOUT                       104
#define IDI_USINGOPENCV                 107
#define IDI_SMALL                       108
#define IDC_USINGOPENCV                 109
#define IDR_MAINFRAME                   128
#define IDC_STATIC						130
#define ID_LST_LOADED_FILES				135
#define	ID_DIA_LOADED_FILES				140
//#define IDC_BUTTON1                     1000


#define IDM_LOAD_MOV                     300
#define IDM_GRAB_PICS					 305
#define IDM_MOVIE_TO_PICS				 307
#define IDM_UNLOAD_MOV				     310
#define IDM_SHOW_FRAME					 312
#define IDM_EXIT                         315


#define IDM_PLAY_MOV                     320
#define IDM_WRITE_MOV					 330

#define IDM_STOP_MOVIE                   360

#define IDM_SHOW_FILES					 370

//CONTROLS
#define IDC_BUTTON_DO_IT                 500
#define IDC_EDIT_START					 510
#define IDC_STATIC_START				 520
#define IDC_EDIT_STOP					 530
#define IDC_STATIC_STOP				     540
#define IDC_STATIC_PATH					 550
#define IDC_EDIT_PATH					 560
#define IDC_TRACKBAR					 570	
#define IDC_EDIT_TRACKBAR_INFO			 590
//#define IDC_BUTTON_BAR_POS			   600
#define IDC_CKECK_BOX_BLUR				 610
#define IDC_CKECK_BOX_ERODE				 620
#define IDC_CKECK_BOX_DILATE			 630
#define IDC_CKECK_BOX_CONT_THRESH		 640
#define IDC_CKECK_BOX_CONT_MAXLEVEL		 650

#define IDC_CLOSE_LOADED_FILES			 670

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NO_MFC                     1
#define _APS_NEXT_RESOURCE_VALUE        129
#define _APS_NEXT_COMMAND_VALUE         32776
#define _APS_NEXT_CONTROL_VALUE         1001
#define _APS_NEXT_SYMED_VALUE           110
#endif
#endif
